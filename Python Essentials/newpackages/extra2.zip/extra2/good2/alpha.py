#! /usr/bin/env python3

""" example module: extra.good.alpha """

def FunA():
	return "Alpha 2"

if __name__ == "__main__":
	print("I prefer to be a module")